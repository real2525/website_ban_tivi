var yourname=document.getElementById("yourname");
var birthday=document.getElementById("birthday");
var username=document.getElementById("username");
var password=document.getElementById("password");
var passwordagain=document.getElementById("passwordagain");
var email=document.getElementById("email");
var sdt=document.getElementById("number");
var gender=document.getElementById("gender");
var frm_dangky=document.getElementById("frm_dangky");


function check()
{
    //if(yourname.value=="")
    //{
    //    document.getElementById("txt1").innerHTML="Chưa nhập tên của bạn hoặc bạn cố ý nhập ký tự đặc biệt";
    //    return false;
    //}
    //return true;
    
}